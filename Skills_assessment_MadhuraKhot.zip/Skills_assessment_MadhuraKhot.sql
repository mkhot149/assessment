-- =========================================================
-- Loading the data from file
-- =========================================================
/* Using MySQL DB called test */
USE test;

/* Creating the table to load the data from CSV file */
DROP TABLE if exists HEALTH;

CREATE TABLE HEALTH (
    id VARCHAR(20),
    race_ethnicity VARCHAR(50),
    sex VARCHAR(5),
    firstencounter DATE,
    lastencounter DATE,
    primary_dx_category VARCHAR(5)
);

/* As a prerequisite, given Excel file was converted to a CSV file. Then the CSV file is read into the table HEALTH in MySQL */
SET GLOBAL local_infile = 'ON';

LOAD DATA LOCAL INFILE 'C:/Users/Akshay/Desktop/Comagine/Test Dataset - Jun 2021 - Associate Healthcare Data Analyst.csv'
INTO TABLE HEALTH
FIELDS TERMINATED BY ','
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(id, race_ethnicity, sex, @datevar1, @datevar2,primary_dx_category)
SET firstencounter = STR_TO_DATE(@datevar1,'%m/%d/%Y'),
	lastencounter = CASE 
						WHEN coalesce(@datevar2,'') <> '' 
                        THEN STR_TO_DATE(@datevar2,'%m/%d/%Y')
						ELSE NULL /*to ensure blank dates get a value of NULL and not 0000-00-00 defaulted by STR_TO_DATE fn*/
                    END;
 
/* Checking if all the data got loaded properly*/
SELECT * FROM HEALTH;

 /* to check if null values have been retained */
SELECT DISTINCT lastencounter
FROM HEALTH; 

-- ================================================================
-- Q1. Identify any issues with and clean the dataset if necessary;
-- ================================================================

/* Checking all the distinct values for the field race_ethnicity */
SELECT DISTINCT
    race_ethnicity
FROM
    health
ORDER BY race_ethnicity;

/* Creating a table "race_correction" for harmonizing the different values 
	e.g. harmonizing both 'hispanic' & 'HISPANIC/LATINO' to 'Hispanic/Latino' 
	Note: Using a table for this purpose is advantageous as 
		we can add/modify values in this table as needed without changing the rest of the process.
*/
DROP TABLE if exists race_correction;

CREATE TABLE race_correction (
    parameter_in VARCHAR(50),
    parameter_out VARCHAR(50)
);

INSERT INTO race_correction
	(parameter_in, parameter_out)
VALUES 
	('african american', 'African American'),
    ('AFRICAN-AMERICAN', 'African American'),
    ('black', 'African American'),
    ('hispanic', 'Hispanic/Latino'),
    ('HISPANIC/LATINO', 'Hispanic/Latino'),
    ('Native american', 'Native American/Alaska Native'),
	('caucasian', 'White');


/* Checking if any undesired characters got added to the following fields while loading data:
	"sex", "firstencounter", "lastencounter" & "primary_dx_category"
    */
SELECT 
    LENGTH(id),
    LENGTH(race_ethnicity),
    LENGTH(sex),
    LENGTH(firstencounter),
    LENGTH(lastencounter),
    LENGTH(primary_dx_category)
FROM
    health
LIMIT 1;

/* Cleaned & harmonized data is written to a new table called health_clean*/
DROP TABLE if exists health_clean;

CREATE TABLE health_clean LIKE health;

INSERT INTO health_clean
	SELECT h.id,
			CASE 
				WHEN r.parameter_out IS NULL THEN h.race_ethnicity
				ELSE r.parameter_out
				END As race_ethnicity_new, 
			h.sex,
			h.firstencounter,
			h.lastencounter,
			LEFT(h.primary_dx_category,3) AS primary_dx_category  -- to remove the undesired character that got added to the end
	FROM health h
	LEFT JOIN race_correction r
	ON h.race_ethnicity = r.parameter_in;

-- =========================================================
-- Q2. Identify average length of service by race/ethnicity
-- =========================================================
SELECT 
    race_ethnicity,
    AVG(DATEDIFF(lastencounter, firstencounter)) AS length_of_service
FROM
    health_clean
WHERE
    lastencounter IS NOT NULL /* to exclude the individuals who are still enrolled */
GROUP BY race_ethnicity;

-- ===================================================================================================================
-- Q3. Identify what percentage of individuals are female and have a primary diagnosis of an alcohol-related disorder;
-- ===================================================================================================================
/* Percent = (No of individuals that are female & have primary diagnosis of alcohol related disorder(F10)) / Total no of individuals */
SELECT 
    (tbl_f_alc.cnt_f_alc * 100 / tbl_all.cnt_total) AS pct_f_alc
FROM
    (
		SELECT COUNT(id) AS cnt_f_alc
		FROM health_clean
		WHERE sex = 'F'
		AND primary_dx_category = 'F10' /* F10 is the ICD-10 code for alcohol-related disorder */
	) AS tbl_f_alc,
    (
		SELECT COUNT(id) AS cnt_total
		FROM health_clean
	) AS tbl_all
;

-- ===============================================================================================
-- Q4. Care management staff may be interested in the following insight:
-- Disorder diagnosis distribution by sex (filterable by race/ethnicity in Power BI dashboard)
-- ===============================================================================================
SELECT 
    primary_dx_category, sex, COUNT(id) AS primary_dx_count
FROM
    health_clean
GROUP BY primary_dx_category , sex
ORDER BY primary_dx_category , sex;